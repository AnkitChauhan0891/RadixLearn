<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>
<?php include 'function.php'; ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / Basic PHP-1 / Basic Calculater</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1" start="2">
            <li>Swap Two Numbers<br>
                Create form which takes two numbers from input field and on submission it should display swapped values<br>
                Note: Create one function which should not return any value

            </li>
        </ol>
        <div class="mx-auto w-50 border border-4 p-4 m-5" style="border-radius: 13px;">
            <form action="swapvalue.php" method="post">
                <h3 class="text-center mb-3">Swap Value</h3>
                <div class="mb-3">
                    <label for="num1" class="form-label">Please enter first number</label>
                    <input type="number" step='0.001' name="num1" placeholder="First number" class="form-control" autocomplete="off" id="num1">
                </div>
                <div class="mb-3">
                    <label for="num2" class="form-label">Please enter second number</label>
                    <input type="number" step='0.001' name="num2" placeholder="Second number" class="form-control" autocomplete="off" id="num2">
                </div>
                <div class="d-flex justify-content-center mb-3">
                    <input type="submit" class="btn btn-primary px-5" name="submit" value="submit">
                </div>
                <div>
                    <strong class="text-danger">
                        <?php
                        if (isset($_POST['submit'])) {
                            $num1 = $_POST['num1'];
                            $num2 = $_POST['num2'];
                            swapValue($num1, $num2);
                            echo "Result : \$num1 = $num1 & \$num2 = $num2";
                        }
                        ?>
                    </strong>
                </div>
            </form>
        </div>
    </div>


    <?php include '../../footer.php'; ?>