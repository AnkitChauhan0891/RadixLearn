<?php include '../../header.php'; ?>
<?php include '../sidebar.php'; ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / String Exercise / Remove Comma</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1" start="5">
            <li>Display multidimensional array values at single level using function.</li>
        </ol>
        <div class="ms-4">
            <div>
                <p class="">Input array : </p>
                <p class="ms-4">
                    <?php 
                    $arr =  array( 'a' => 100,'b' => 200,'c' => array ( 'c1' => 300, 'c2' => 400),'d' => 500,'e' => array ( 'e1' => 600, 'e2' => 700));
                    echo "<pre>";
                     print_r($arr);
                    echo "</pre>";
                    ?>
                </p>
            </div>

            <div>
                <p class=""> Output : </p>
                <p class="ms-4">
                    <?php
                        // function arrayMerge($arr){
                           
                        // }
                    ?>
                </p>
            </div>


        </div>
    </div>


    <?php include '../../footer.php'; ?>