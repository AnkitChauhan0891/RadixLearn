<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>
<?php include 'function.php'; ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / Basic PHP-1 / Basic Calculater</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1" start="6">
            <li>Create one form which contains 5 person’s Name and birthdate of person.<br/>
            On submit make table of entered data show using function:<br/>
            Give delete button in every row which deletes that particular row on click.<br/>
            </li>
        </ol>
        <div class="mx-auto w-75 border border-4 p-4 m-5" style="border-radius: 13px;">
            <form action="deleteOperation.php" method="post">
                <h3 class="text-center mb-3">Delete Operation</h3>
                <div class="mb-3">
                    <label for="firstPersomName" class="form-label">1st person's name</label>
                    <input type="text" name="firstPersonName" placeholder="Please enter 1st person's name" class="form-control" autocomplete="off">
                </div>
                <div class="mb-3">
                    <label for="firstPersonDOB" class="form-label">1st person's DOB</label>
                    <input type="date" name="firstPersonDOB" placeholder="Please enter 1st person's DOB" class="form-control" autocomplete="off" id="num2">
                </div>

                <div class="mb-3">
                    <label for="firstPersomName" class="form-label">2nd person's name</label>
                    <input type="text" name="secondPersonName" placeholder="Please enter 2nd person's name" class="form-control" autocomplete="off">
                </div>
                <div class="mb-3">
                    <label for="firstPersonDOB" class="form-label">2nd person's DOB</label>
                    <input type="date" name="secondPersonDOB" placeholder="Please enter 2nd person's DOB" class="form-control" autocomplete="off" id="num2">
                </div>

                <div class="mb-3">
                    <label for="firstPersomName" class="form-label">3rd person's name</label>
                    <input type="text" name="thirdPersonName" placeholder="Please enter 3rd person's name" class="form-control" autocomplete="off">
                </div>
                <div class="mb-3">
                    <label for="firstPersonDOB" class="form-label">3rd person's DOB</label>
                    <input type="date" name="thirdPersonDOB" placeholder="Please enter 3rd person's DOB" class="form-control" autocomplete="off" id="num2">
                </div>

                <div class="mb-3">
                    <label for="firstPersomName" class="form-label">4th person's name</label>
                    <input type="text" name="forthPersonName" placeholder="Please enter 4th person's name" class="form-control" autocomplete="off">
                </div>
                <div class="mb-3">
                    <label for="firstPersonDOB" class="form-label">4th person's DOB</label>
                    <input type="date" name="forthPersonDOB" placeholder="Please enter 4th person's DOB" class="form-control" autocomplete="off" id="num2">
                </div>

                <div class="mb-3">
                    <label for="firstPersomName" class="form-label">5th person's name</label>
                    <input type="text" name="fifthPersonName" placeholder="Please enter 5th person's name" class="form-control" autocomplete="off">
                </div>
                <div class="mb-3">
                    <label for="firstPersonDOB" class="form-label">5th person's DOB</label>
                    <input type="date" name="fifthPersonDOB" placeholder="Please enter 5th person's DOB" class="form-control" autocomplete="off" id="num2">
                </div>
               
                <div class="d-flex justify-content-center mb-3">
                    <input type="submit" class="btn btn-primary px-5" name="submit" value="submit">
                </div>
                <div>
                    <strong class="text-danger">
                        <?php
                        if (isset($_POST['submit'])) {
                            $arr = array(array('name'=>$_POST['firstPersonName'],'dob'=>$_POST['firstPersonDOB']),array('name'=>$_POST['secondPersonName'],'dob'=>$_POST['secondPersonDOB']),
                            array('name'=>$_POST['thirdPersonName'],'dob'=>$_POST['thirdPersonDOB']),array('name'=>$_POST['forthPersonName'],'dob'=>$_POST['forthPersonDOB']),
                            array('name'=>$_POST['fifthPersonName'],'dob'=>$_POST['fifthPersonDOB']));

                            displayData($arr);

                        }
                        ?>
                    </strong>
                </div>
            </form>
        </div>
    </div>

    
    <?php include '../../footer.php'; ?>