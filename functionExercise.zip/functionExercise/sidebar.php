<aside aria-label="" class="column_left">
    <ul id="show3">
        <li class="module">
            <button type="button" class="collapsible">Overview PHP</button>
            <div class="content">
                <ul class="task">
                    <li>
                        <ol class="task2">
                            <li><a href="<?php echo SITE_URL.'PHP-training/overviewPHP/getPHPInfo.php'?>">PHP Info</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/overviewPHP/displayString.php'?>">Display String</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/overviewPHP/echo-print.php'?>">Echo & Print</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/overviewPHP/login.php'?>">Login</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/overviewPHP/registration.php'?>">Registartion</a></li>
                        </ol>
                    </li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Basic PHP-1</button>
            <div class="content">
                <ul class="task">
                    <li>
                        <ol class="task2">
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP1/basicCalculater.php'?>">Basic Calculater</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP1/displayMessage.php'?>">Display Message</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP1/currency.php'?>">Currency</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP1/bmi.php'?>">Calculate BMI</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP1/validationBmi.php'?>">Validation BMI</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP1/imageQuize.php'?>">Image Quize</a></li>
                        </ol>
                    </li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Basic PHP-2</button>
            <div class="content">
                <ul class="task">
                    <li>
                        <ol class="task2">
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP2/dateFormats.php'?>">Date Formats</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP2/computedAge.php'?>">Computed Age</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP2/differenceDate.php'?>">Difference Date</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP2/validDate.php'?>">Valid Date</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP2/monthName.php'?>">Month Name</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP2/checkPower.php'?>">Check Power</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP2/squareRoot.php'?>">Square Root</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP2/reverseNumber.php'?>">Reverse Number</a></li>
                        </ol>
                    </li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Basic PHP-3</button>
            <div class="content">
                <ul class="task">
                    <li>
                        <ol class="task2">
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP3/basicForm.php'?>">Basic Form</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP3/serverIp.php'?>">Server IP</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP3/browserDetection.php'?>">Browser Detection</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP3/getFileName.php'?>">Get File Name</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP3/checkProtocol.php'?>">Check Protocol</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP3/checkSubString.php'?>">Check Sub String</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP3/removeLastWord.php'?>">Remove Last Word</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP3/removeWhiteSpace.php'?>">Remove White Space</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP3/removeNonNumeric.php'?>">Remove Non Numeric</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP3/removeNewLine.php'?>">Remove New Line</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/basicPHP3/basicValidationForm.php'?>">Basic Validation Form</a></li>
                        </ol>
                    </li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Array Exercise</button>
            <div class="content">
                <ul class="task">
                    <li>
                        <ol class="task2">
                            <li><a href="<?php echo SITE_URL.'PHP-training/arrayExercise/arrayFunction.php'?>">Array Function</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/arrayExercise/arrayOperation.php'?>">Array Operation</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/arrayExercise/displayTemperature.php'?>">Display Temperature</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/arrayExercise/serializeString.php'?>">Serialize String</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/arrayExercise/insertItemInArray.php'?>">Insert Item In Array</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/arrayExercise/arrayUpperOrLowerCase.php'?>">Upper & Lower Case</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/arrayExercise/mergeArray.php'?>">Merge Array</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/arrayExercise/printArrayData.php'?>">Print Array Data</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/arrayExercise/arraySorting.php'?>">Array Sorting</a></li>
                        </ol>
                    </li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">String Exercise</button>
            <div class="content">
                <ul class="task">
                    <li>
                        <ol class="task2">
                            <li><a href="<?php echo SITE_URL.'PHP-training/stringExercise/removeComma.php'?>">Remove Comma</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/stringExercise/replaceCharacters.php'?>">Replace Characters</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/stringExercise/getCharacters.php'?>">Get Characters</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/stringExercise/insertString.php'?>">Insert String</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/stringExercise/getEmailDomain.php'?>">Get Email Domain</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/stringExercise/getNextCharacters.php'?>">Get Next Character</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/stringExercise/getFileName.php'?>">Get File Name</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/stringExercise/stringToArray.php'?>">String To Array</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/stringExercise/differencePosition.php'?>">Difference Position</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/stringExercise/replaceFirstWord.php'?>">Replace First Word</a></li>
                        </ol>
                    </li>
                </ul>
            </div>
        </li>
        <li class="module">
            <button type="button" class="collapsible">Function Exercise</button>
            <div class="content">
                <ul class="task">
                    <li>
                        <ol class="task2">
                            <li><a href="<?php echo SITE_URL.'PHP-training/functionExercise/basicCalculater.php'?>">Basic Calculater</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/functionExercise/swapValue.php'?>">Swap Value</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/functionExercise/basicOperationCalculater.php'?>">Basic Operation Calculater</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/functionExercise/oneArgumentCalculater.php'?>">One Argument Calculater</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/functionExercise/arrayMergeRecursive.php'?>">Array Merge Recursive</a></li>
                            <li><a href="<?php echo SITE_URL.'PHP-training/functionExercise/deleteOperation.php'?>">Delete Operation</a></li>
                        </ol>
                    </li>
                </ul>
            </div>
        </li>
    </ul>
</aside>    