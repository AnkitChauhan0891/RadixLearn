<?php

    function basicCalculater($num1,$num2,$operation){

        if($operation == "")
        {
            $operation = "addition";
        }

        switch ($operation) {
            case 'addition':
                echo 'Result : ' . $num1 + $num2;
                break;

            case 'subtraction':
                echo 'Result : ' . $num1 - $num2;
                break;

            case 'multiplication':
                echo 'Result : ' . $num1 * $num2;
                break;

            case 'division':
                echo 'Result : ' . $num1 / $num2;
                break;

            default:
                echo 'Please Select operation';
                break;
        }
    }

    function swapValue(&$num1,&$num2){
        $temp = $num1;
        $num1 = $num2;
        $num2 = $temp;
    }

    function basicOperationCalculater($num1, $num2){
        $count = 0;

        $sum = $num1 + $num2;
        $count++;

        $sub = $num1 - $num2;
        $count++;

        $mul = $num1 * $num2;
        $count++;

        $div = $num1 / $num2;
        $count++;


        echo "Result :<p class='ms-5'> <br> sum = $sum <br> sub = $sub <br> mul = $mul <br> div = $div <br> count : $count </p>";
    }

    function oneArgumentCalculater($num1,$num2,$operation){
        switch ($operation) {
            case 'addition':
                echo 'Result : ' . $num1 + $num2;
                break;

            case 'subtraction':
                echo 'Result : ' . $num1 - $num2;
                break;

            case 'multiplication':
                echo 'Result : ' . $num1 * $num2;
                break;

            case 'division':
                echo 'Result : ' . $num1 / $num2;
                break;

            default:
                echo 'Please Select operation';
                break;
        }
    }

    function displayData($arr){
        $str = "<table><tr style='background-color: #FF8800 !important; width:100% !important'><th>Sr No.</th><th>Name</th><th>Age</th><th>Action</th></tr>";
        $count = 1;
        foreach($arr as $key=>$tmp)
        {
            $age = calculateAge($tmp['dob']);
            $str .= "<tr><td class='id' style='display:none'>" . $key . "</td><td>" . $count . "</td><td class='name'>" . $tmp['name'] . "</td><td class='age'>$age</td><td><input type='button' value='Remove to cart' class='btn btn-outline-danger btn-sm''></td></tr>";
            $count++;
        }
        $str .= "</tabel>";
        echo $str;
    }

    function calculateAge($dob)
    {
        $birthdate = date_create($dob);
        $date = date_create(date("Y-m-d"));
        $res = date_diff($birthdate,$date)->format('%y');
        return $res;
    }

    calculateAge("2022-04-21");
    
?>
