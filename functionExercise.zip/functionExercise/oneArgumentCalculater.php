<?php include '../../header.php'; ?>
<?php include '../sidebar.php' ?>
<?php include 'function.php'; ?>

<aside aria-label="" class="column_right" style="overflow-x: hidden !important">
    <h1 class="path">PHP / Basic PHP-1 / Basic Calculater</h1>
    <div class="right_content bg-dark text-white">
        <ol type="1" start="4">
            <li>Implement same calculator functionality with all operations.<br/>
                Create function with only one argument (type of operation), perform all operations for numbers 20 and 10 and outputs the result<br/>
                Note: Numbers must not be declared inside the function
            </li>
        </ol>
        <div class="mx-auto w-50 border border-4 p-4 m-5" style="border-radius: 13px;">
            <form action="oneArgumentCalculater.php" method="post">
                <h3 class="text-center mb-3">Basic Calculater</h3>
                <div class="mb-4">
                    <label for="operation" class="form-label">Operation</label>
                    <select name="operation" id="operation" class="form-control">
                        <option value="" selected>Select operation...</option>
                        <option value="addition">Addition</option>
                        <option value="subtraction">Subtraction</option>
                        <option value="multiplication">Multiplication</option>
                        <option value="division">Division</option>
                    </select>
                </div>
                <div class="d-flex justify-content-center mb-3">
                    <input type="submit" class="btn btn-primary px-5" name="submit" value="submit">
                </div>
                <div>
                    <strong class="text-danger">
                        <?php
                        if (isset($_POST['submit'])) {
                            $num1 = 20;
                            $num2 = 10;
                            $operation = $_POST['operation'];
                            oneArgumentCalculater($num1,$num2,$operation);
                        }
                        ?>
                    </strong>
                </div>
            </form>
        </div>
    </div>

    
    <?php include '../../footer.php'; ?>